import { combineReducers } from 'redux';
import attendance from '../domains/attendance/state/AttendanceReducer';
import attendanceDashboard from '../domains/attendanceDashboard/state/AttendanceDashboardReducer';
import auth from '../domains/auth/AuthReducer';
import contact from '../domains/contactModal/ContactModalReducer';
import generator from '../domains/qr/generator/state/GeneratorReducer';
import organizationUsers from '../domains/organization/organization-users/OrganizationUsersReducer';
import surveyReports from '../domains/surveys/survey-reports/state/SurveyReportsReducer';
import busAttendance from '../domains/schoolBus/bus-attendance/state/BusAttendenceReducer';
import attendanceVisitors from '../domains/attendanceVisitors/state/AttendanceVisitorsReducer';
import surveys from '../domains/surveys/surveys-all/state/SurveysReducer';
import studentProfile from '../domains/studentProfile/state/StudentProfileReducer';
import orgStudents from '../domains/organization/organization-students/state/OrgStudentsReducer';
import organizations from '../domains/organizations/state/OrganizationsReducer';

export default combineReducers({
  attendance,
  attendanceDashboard,
  auth,
  busAttendance,
  contact,
  generator,
  organizationUsers,
  orgStudents,
  surveyReports,
  attendanceVisitors,
  surveys,
  studentProfile,
  organizations,
});
